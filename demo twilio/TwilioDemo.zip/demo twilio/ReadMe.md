# Twilio SMS 

### Instructions

```
* Change in files:
  account_sid: #your account sid
  auth_token: #your auth token
  trial_number: # your trial number
* Simply execute the code to send a test SMS of your choosing
```

